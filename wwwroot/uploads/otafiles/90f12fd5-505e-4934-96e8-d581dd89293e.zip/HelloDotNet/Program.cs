﻿Hewan hewan1 = new Kucing("Kitty");
Hewan hewan2 = new Anjing("Bello");

hewan1.Suara();  // Output: Kitty mengatakan Meong!
hewan2.Suara();  // Output: Bello mengatakan Guk-Guk!
