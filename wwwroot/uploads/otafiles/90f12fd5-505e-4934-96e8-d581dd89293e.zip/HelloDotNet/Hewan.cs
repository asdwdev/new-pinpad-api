public class Hewan
{
    public string Nama { get; }

    public Hewan(string nama)
    {
        Nama = nama;
    }

    public virtual void Suara()
    {
        Console.WriteLine($"{Nama} mengeluarkan suara.");
    }
}

public class Kucing : Hewan
{
    public Kucing(string nama) : base(nama)
    {
    }

    public override void Suara()
    {
        Console.WriteLine($"{Nama} mengatakan Meong!");
    }
}

public class Anjing : Hewan
{
    public Anjing(string nama) : base(nama) { }

    public override void Suara()
    {
        Console.WriteLine($"{Nama} mengatakan Guk-Guk!");
    }
}